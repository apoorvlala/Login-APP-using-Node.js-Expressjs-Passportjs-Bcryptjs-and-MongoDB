var express=require('express');
var router=express.Router();
var passport=require('passport');
var LocalStrategy=require('passport-local').Strategy;
const User=require('../models/users');
const { check, validationResult } = require('express-validator/check');
router.get('/register',(req,res)=>{
    res.render('registeration');
});

router.get('/login',(req,res)=>{
    res.render('login');
});

router.post('/register',[
    check('name','Error in Name').isLength({min:1}),
    check('username','Error in Username').isLength({min:1}),
    check('email','Error in email').isEmail(),
    check("password", "invalid password").trim().isLength({min:4}),
    check('confirmpass','Errors in confirm password').custom((value,{req})=>{
        if(value != req.body.password){
            throw new Error("Password do not match");
        }else{
            return true;
        }
    }),
],(req,res)=>{
    const errors=validationResult(req);
    if(!errors.isEmpty()){
        console.log(errors.mapped());
        res.render('registeration',{errors:errors.mapped()});
    }else{
        var name=req.body.name;
        var username=req.body.username;
        var email=req.body.email;
        var password=req.body.password;        
        var newUser=new User({
            name:name,
            username:username,
            email:email,
            password:password
        });
        User.createUser(newUser ,(err,user)=>{
            if(err)throw err;
            console.log(user);
        });
        req.flash('success_msg','You are registere and you can now login...');
        res.redirect('/users/login');
    }       
});

passport.use(new LocalStrategy((username, password, done)=> {
      User.getUserByUsername(username,(err,user)=>{
          if(err)throw err;
          if(!user){
              return done(null ,false ,{message:"Unknown User"});
          }
          User.comparePassword(password , user.password,(err,isMatch)=>{
                if(err)throw err;
                if(isMatch){
                    return done(null,user);
                }else{
                    return done(null,false,{message:"Invalid password"});
                }
          });
      });
    }
  ));

  passport.serializeUser(function(user, done) {
    done(null, user.id);
  });
  
  passport.deserializeUser(function(id, done) {
    User.getUserById(id, function(err, user) {
      done(err, user);
    });
  });


router.post(
    '/login',
    passport.authenticate('local',{ successRedirect: '/',failureRedirect: '/users/login',failureFlash:true}), 
    (req,res)=>{
            res.redirect('/');
        }
    );

    router.get('/logout',(req,res)=>{
        req.logout();
        req.flash('success_msg','You are logged out');
        res.redirect('/users/login');
    });

module.exports=router;